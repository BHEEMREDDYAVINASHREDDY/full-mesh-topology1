import java.util.*;

class WorkStation {
    String name;
    String ip;
    Set<WorkStation> connections;

    public WorkStation(String name, String ip) {
        this.name = name;
        this.ip = ip;
        this.connections = new HashSet<>();
    }
}

class FullMeshTopology {
    Map<String, WorkStation> nodes;

    public FullMeshTopology() {
        nodes = new HashMap<>();
    }

    public void addNode(String name, String ip) {
        if (nodes.containsKey(ip)) {
            System.out.println("IP address already in use. Please choose a different IP address.");
            suggestIPAddresses();
        } else {
            WorkStation newNode = new WorkStation(name, ip);
            for (WorkStation existingNode : nodes.values()) {
                existingNode.connections.add(newNode);
                newNode.connections.add(existingNode);
            }
            nodes.put(ip, newNode);
            System.out.println("Node " + name + " with IP " + ip + " added and connected to all other nodes.");
        }
    }

    public void suggestIPAddresses() {
        Set<String> usedIPs = nodes.keySet();
        for (int i = 1; i <= 255; i++) {
            String suggestedIP = "192.168.1." + i;
            if (!usedIPs.contains(suggestedIP)) {
                System.out.println("Suggested IP: " + suggestedIP);
            }
        }
    }

    public void connectionTest(String targetIP) {
        if (!nodes.containsKey(targetIP)) {
            System.out.println("Node not found.");
            return;
        }

        WorkStation targetNode = nodes.get(targetIP);
        List<List<WorkStation>> bfsResult = bfsRead(targetNode);
        System.out.println("Nodes connected to " + targetNode.name + " at different levels:");
        for (int level = 0; level < bfsResult.size(); level++) {
            System.out.print("Level " + level + ": ");
            for (WorkStation node : bfsResult.get(level)) {
                System.out.print(node.name + " ");
            }
            System.out.println();
        }
    }

    public List<List<WorkStation>> bfsRead(WorkStation startNode) {
        Set<WorkStation> visited = new HashSet<>();
        List<List<WorkStation>> result = new ArrayList<>();
        Queue<WorkStation> queue = new LinkedList<>();

        queue.offer(startNode);
        visited.add(startNode);

        while (!queue.isEmpty()) {
            int levelSize = queue.size();
            List<WorkStation> levelNodes = new ArrayList<>();

            for (int i = 0; i < levelSize; i++) {
                WorkStation node = queue.poll();
                levelNodes.add(node);

                for (WorkStation neighbor : node.connections) {
                    if (!visited.contains(neighbor)) {
                        queue.offer(neighbor);
                        visited.add(neighbor);
                    }
                }
            }

            result.add(levelNodes);
        }

        return result;
    }

    public static void main(String[] args) {
        FullMeshTopology network = new FullMeshTopology();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nChoose an option:");
            System.out.println("1. Add Node");
            System.out.println("2. Connection Test");
            System.out.println("3. Exit");
            System.out.print("Enter your choice (1/2/3): ");
            String choice = scanner.nextLine();

            if (choice.equals("1")) {
                System.out.print("Enter the node name: ");
                String name = scanner.nextLine();
                System.out.print("Enter the node IP address: ");
                String ip = scanner.nextLine();
                network.addNode(name, ip);
            } else if (choice.equals("2")) {
                System.out.print("Enter the IP address of the node for connection test: ");
                String targetIP = scanner.nextLine();
                network.connectionTest(targetIP);
            } else if (choice.equals("3")) {
                System.out.println("Exiting the program.");
                break;
            } else {
                System.out.println("Invalid choice. Please select 1, 2, or 3.");
            }
        }

        scanner.close();
    }
}
